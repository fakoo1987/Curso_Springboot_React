package net.purocodigo.backendcursojava;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendcursojavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
